﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewComponents;
using ViewComponents.Context;

namespace ViewComponents.ViewComponents;

public class CategoryListViewComponent:ViewComponent
{
    private readonly AppDbContext _context;

    public CategoryListViewComponent(AppDbContext context)
    {
        _context = context;
    }

    public ViewViewComponentResult Invoke()
    {
        return View(
            new CategoryListViewModel
            {
                Categories = _context.Categories.ToList(),
            });
    }
}