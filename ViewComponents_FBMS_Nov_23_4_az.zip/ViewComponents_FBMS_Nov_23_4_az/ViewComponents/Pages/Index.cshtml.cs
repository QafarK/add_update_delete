using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ViewComponents.Context;
using ViewComponents.Entites;

namespace ViewComponents.Pages;

public class IndexModel(AppDbContext context) : PageModel
{
    private readonly AppDbContext _context = context;

    public string Message { get; set; }
    public List<Product> Products { get; set; }

    public void OnGet()
    {
        Products = _context.Products.ToList();
        Message = $"Now date is {DateTime.Now.DayOfWeek}";
    }
  
    [BindProperty]
    public Product Product { get; set; }

	[BindProperty]
	public int Id { get; set; }

	[BindProperty]
	public string Name { get; set; }

	[BindProperty]
	public decimal Price { get; set; }


	public IActionResult OnPostAdd()
    {
		if(Product == null)
		{
			return NotFound();
		}
        _context.Products.Add(Product);
        _context.SaveChanges();
        return RedirectToPage("Index");
    }

	public IActionResult OnPostUpdate()
	{
		var product = _context.Products.FirstOrDefault(p => p.Id == Id);
		if (product == null)
		{
			return NotFound();
		}

		product.Name = Product.Name;
		product.Price = Product.Price;
		_context.SaveChanges();
		return RedirectToPage("Index");
	}

	public IActionResult OnPostDelete(int id)
	{
		var it = id;
		var asda = _context.Products;
		var product = _context.Products.FirstOrDefault(p => p.Id == id);
		if (product == null)
		{
			return NotFound();
		}

		_context.Products.Remove(product);
		_context.SaveChanges();
		return RedirectToPage("Index");
	}


}
