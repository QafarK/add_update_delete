using Microsoft.AspNetCore.Mvc;
using ViewComponents.Context;

namespace ViewComponents.Controllers;

public class HomeController(AppDbContext context) : Controller
{
    private readonly AppDbContext _context = context;

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult GetCategories()
    {
        return Json(_context.Categories);
    }
}