﻿using ViewComponents.Entites;

namespace ViewComponents;

public class CategoryListViewModel
{
    public List<Category> Categories { get; set; }
}